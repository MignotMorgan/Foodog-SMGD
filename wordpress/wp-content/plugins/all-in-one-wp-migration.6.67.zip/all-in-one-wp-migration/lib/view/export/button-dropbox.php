<a href="https://servmask.com/products/dropbox-extension" target="_blank"><?php _e( 'Dropbox', AI1WM_PLUGIN_NAME ); ?></a>
